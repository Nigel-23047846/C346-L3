import React, { useState } from 'react';
import { View, Text, Button, Alert, Image, StyleSheet, ScrollView } from 'react-native';
import RNPickerSelect from 'react-native-picker-select';

const QuizApp = () => {
    const questions = [
        {
            id: 1,
            image: require('./assets/lion.jpg'),
            question: 'What animal is shown?',
            options: ['Lion', 'Tiger', 'Elephant'],
            correctAnswer: 'Lion',
        },
        {
            id: 2,
            image: require('./assets/Tiger.jpg'),
            question: 'What animal is shown?',
            options: ['Lion', 'Tiger', 'Elephant'],
            correctAnswer: 'Tiger',
        },
        {
            id: 3,
            image: require('./assets/Elephant.jpg'),
            question: 'What animal is shown?',
            options: ['Lion', 'Tiger', 'Elephant'],
            correctAnswer: 'Elephant',
        },
    ];

    const [answers, setAnswers] = useState({});

    const handleSelect = (value, questionId) => {
        setAnswers(prevAnswers => ({ ...prevAnswers, [questionId]: value }));
    };

    const handleSubmit = () => {
        let score = 0;
        let allAnswered = true;

        questions.forEach(question => {
            if (answers[question.id] === question.correctAnswer) score++;
            if (!answers[question.id]) allAnswered = false;
        });

        if (!allAnswered) {
            Alert.alert('Please answer all questions before submitting.');
        } else {
            Alert.alert(`You got ${score} out of ${questions.length} correct!`);
        }
    };

    return (
        <ScrollView contentContainerStyle={styles.container}>
            {questions.map((question) => (
                <View key={question.id} style={styles.questionContainer}>
                    <Image source={question.image} style={styles.image} />
                    <Text style={styles.questionText}>{question.question}</Text>
                    <RNPickerSelect
                        onValueChange={(value) => handleSelect(value, question.id)}
                        items={question.options.map(option => ({ label: option, value: option }))}
                        placeholder={{ label: 'Select an answer...', value: null }}
                    />
                </View>
            ))}
            <Button title="Submit Answers" onPress={handleSubmit} />
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        padding: 20,
        backgroundColor: '#f5f5f5',
        alignItems: 'center',
    },
    questionContainer: {
        marginBottom: 20,
        alignItems: 'center',
        width: '100%',
    },
    image: {
        width: 200,
        height: 200,
        marginBottom: 10,
    },
    questionText: {
        fontSize: 18,
        marginBottom: 10,
        textAlign: 'center',
    },
});

export default QuizApp;
